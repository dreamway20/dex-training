const array = [
    {
      type: 'div',
      key: 0,
      props: {
        value: 'one',
      }
    },
    {
      type: 'div',
      key: 1,
      props: {
        value: 'two',
      }
    },
  ];
  
  const newArray = [
    {
      type: 'div',
      key: 0,
    },
  ]